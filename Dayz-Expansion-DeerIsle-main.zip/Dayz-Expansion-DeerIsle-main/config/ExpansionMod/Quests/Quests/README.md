# Loadout Notes
If a Quest has external dependencies, they will be noted here.

## MMGTanLoadout
This requires the ```@MMG - Mightys Military Gear``` mod to be installed. ID ```2663169692```

## UmbrellaLoadout
This requires the ```@Umbrella Clothing``` mod to be installed. ID ```2853118020```