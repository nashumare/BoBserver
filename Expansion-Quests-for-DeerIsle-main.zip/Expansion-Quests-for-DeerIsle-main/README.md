# Expansion-Quests-for-DeerIsle

DayZ-Expansion-Quests 2
Hello everyone, I present my Expansion Quests collection-2. 
This is edited quests from Cherno.
# Instal just simple :
Stop the server and change your quest with mine, normaly I delete old ones and put those new ones. 

I hope it will be useful to someone. For DeerIsle map

# Here only working quest for ExpansionQuestNPCAIDenis !
# ExpansionQuestBoardLarge Not working at the moment (no clue where I made mistake , when I get fix I post it)

